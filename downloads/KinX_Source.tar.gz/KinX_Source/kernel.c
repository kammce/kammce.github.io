/*  Desc: Kernel C Code and Main file */

#include <cpu.h>
#include <core.h>

kmain() //like normal main in C programs
{
    gdt_install();
    idt_install();
    isrs_install();
    irq_install();
    init_video();
    timer_install();
    keyboard_install();
	enableInts();
	kin_dos_install();

	while (1) { hlt(); }
};
