#ifndef __CPU_H
#define __CPU_H

unsigned char inportb (unsigned short _port);
void outportb (unsigned short _port, unsigned char _data);
void hlt(void);
//void invlpg(_dword_union address);
void disableInts(void);
void enableInts(void);

#endif
