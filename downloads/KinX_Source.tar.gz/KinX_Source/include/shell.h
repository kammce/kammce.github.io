/* Desc: Global Declaration of functions and values needed for the KinDOS terminal */

#ifndef __SHELL_H
#define __SHELL_H

#include <core.h>

unsigned char default_prompt[100];
/* CONSOLE.C */
extern void *memcpy(void *dest, const void *src, size_t count);
extern void *memset(void *dest, char val, size_t count);
extern unsigned short *memsetw(unsigned short *dest, unsigned short val, size_t count);
extern size_t strlen(const char *str);
extern size_t strlen2(const char *str);
char * clear_char(char * c1, int sum);
extern unsigned char char_compare (unsigned char c1[100], unsigned char c2[100]);
//unsigned char command_compare (unsigned char * c1, unsigned char * c2);
extern void mem_str_cpy(char *dest, unsigned char mov, int start, int end);
extern void display_cursor_loc();

extern void alter_x(unsigned int new_x);
extern void alter_y(unsigned int new_y);
extern void alter_pl(unsigned int pl);

extern void init_video(void);
extern void puts(unsigned char *text);
extern void putch(unsigned char c);
extern unsigned char putch_return(unsigned char c);
extern void cls();
extern void cls1();

/* KinDOS.c (shell) */
extern void change_prompt(unsigned char *ptext);
extern void prompt_line(unsigned short int activate);
extern void start_kin_dos();
extern void kin_dos_install();
extern void activate_cmd();
extern void buffer_stack(unsigned char add);

/* echo.c */
extern void echo (unsigned char * c1);

#endif
