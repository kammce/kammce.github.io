#ifndef __TYPE_H
#define __TYPE_H

#define NULL '\0'
#define TRUE 1
#define FALSE 0

#endif
