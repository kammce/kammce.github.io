/* Desc: Time and Date program */
#include <core.h>

void display_time()
{
	puts("Sun Apr 29 15:32:33 PDT 2012");
  //puts("SORRY: since network support does not exist at the moment and CMOS can be\nunraliable and dangerous to use, thus the date or time cannot be displayed.");
  return;
}
