#include <core.h>
#include <shell.h>
#include <define.h>

unsigned char command_buffer[100];
unsigned short int command_buffer_count = 0;
//unsigned char colors[] = {0x0F,0x0E,0x0A,0x0F,0x0F,0x0F,0x0F};
unsigned char black = 0x00;
unsigned char white = 0x0F;
unsigned char yellow = 0x0E;
unsigned char brown = 0x06;
unsigned char d_blue = 0x01;
unsigned char l_blue = 0x0F;
unsigned char d_green = 0x02;
unsigned char l_green = 0x0A;
unsigned char d_red = 0x04;
unsigned char l_red = 0x0C;
unsigned char d_gray = 0x07;
unsigned char l_gray = 0x08;
unsigned char d_cyan = 0x03;
unsigned char l_cyan = 0x0B;
unsigned char d_magenta = 0x05;
unsigned char l_magenta = 0x0D;

/*char dir[] = "/home/omega ";
char user[] = "Omega ";
char host[] = "KinX ";
char time_date[] = "";
char command_prompt_as[100];

mem_str_cpy(command_prompt_as,"[ ",0, 2);
mem_str_cpy(command_prompt_as,host, strlen(command_prompt_as), strlen(host));
mem_str_cpy(command_prompt_as,user, strlen(command_prompt_as), strlen(user));
mem_str_cpy(command_prompt_as,"- ", strlen(command_prompt_as), 2);
mem_str_cpy(command_prompt_as,dir, strlen(command_prompt_as), strlen(dir));
mem_str_cpy(command_prompt_as,"]: ", strlen(command_prompt_as), 3);*/


void change_prompt(unsigned char *ptext) {
	int i;
	int col = 0;
	for (i = 0; i < strlen(ptext); i++)
    {
		if(ptext[i] == ' ' || ptext[i] == '@') {
			col++;
			switch (col) {
			case 0:
				settextcolor(white);
				break;
			case 1:
				settextcolor(yellow);
				break;
			case 2:
				settextcolor(d_green);
				break;
			case 3:
				settextcolor(d_cyan);
				break;
			case 4:
				settextcolor(white);
				break;
			default:
				settextcolor(white);
			  break;
			}
		}
		if(ptext[i] != '\0') {
        default_prompt[i] = ptext[i];
		putch(ptext[i]);
		} else { settextcolor(white); break; }
    }
}

void prompt_line(unsigned short int activate) {
	if(activate == 1) {
	activate_cmd();
	return;
	} else { } 
	change_prompt("[ Omega@KinX Kin1 -/home/omega ]: ");
	int pstring = strlen(default_prompt);
	alter_x(pstring);
	alter_pl(pstring);
    move_csr();
}

void start_kin_dos() {
	prompt_line(0);
}
/* Installs the KinDOS handler into IRQ2 */
void kin_dos_install()
{
	/*puts("+----------------------------\n");
	puts(" || /  +        \\ \\  / /   OS \n");
	puts(" ||/   |  |--    \\ \\/ /       \n");
	puts(" |-    |  |  |    \\  /        \n");
	puts(" ||\\   |  |  |   / /\\ \\       \n");
	puts(" || \\  |  |  |  / /  \\ \\      \n");
	puts("+-----------------------------\n\n");*/

	puts("\n");
	puts("+ ----------------------------------\n");
	puts("| Welcome to KinX Operating System \n");
	puts("+ ----------------------------------\n\n");
	puts("KinX Documentation @ http://www.kammcecorp.net/kinx\n");
	puts("KinX Version: 0.01 LTS\n\n");
	prompt_line(0);
    irq_install_handler(2, start_kin_dos);
}
void buffer_stack(unsigned char add) {
	if(add == '\n') { activate_cmd(); return; }
	//if backspace '0x08' is pressed and buffer count is greater than 0
	if(add == 0x08 && (command_buffer_count > 0)) {
		command_buffer_count--;
		command_buffer[command_buffer_count] = '\0';
	}
	else if (add == 0x08 && (command_buffer_count <= 0)) {
		command_buffer_count = 0;
		clear_char(command_buffer,100);
	} else {
		command_buffer[command_buffer_count] = add;
		command_buffer_count++;
	}
}
void activate_cmd() {
    int i;
	unsigned char help[] = "help";
	unsigned char hello[] = "hello";
	unsigned char echo_command[] = "echo";
	unsigned char date[] = "date";
	unsigned char math[] = "math";
	unsigned char cursor[] = "cursor";
	unsigned char clear[] = "cls";
	unsigned char shell_command[100];

	buffer_stack('\0');

	for (i = 0; i < strlen2(command_buffer); i++)
    {
		if(command_buffer[i] != '\0') {
        shell_command[i] = command_buffer[i];
		} else { break; }
    }
	/*putch('\'');
	puts(shell_command);
	puts("\'\n\'");
	puts(command_buffer[]);
	puts("\'\n");*/
	if(shell_command[0] != '\0' && shell_command[0] != ' ') {
		if(command_compare(shell_command,help) == 't') {
			puts("Available Commands: ");
			puts("\nhelp  - Lists the available commands and this prompt.");
			puts("\nhello - Welcome Program.");
			puts("\necho  - display a line of text");
			puts("\ndate  - display date from bios");
			puts("\nmath  - do simple arithmetic");
			puts("\ncursor - display cursor location");
			puts("\ncls   - clear screen");
		}
		else if(command_compare(shell_command,hello) == 't') { puts("Hello! This is KinX's First Command. Thank you for using it!"); }
		else if(command_compare(shell_command,echo_command) == 't') { echo(shell_command); }
		else if(command_compare(shell_command,date) == 't') { display_time(); }
		else if(command_compare(shell_command,math) == 't') { do_math(shell_command); }
		else if(command_compare(shell_command,cursor) == 't') { display_cursor_loc(); }
		else if(command_compare(shell_command,clear) == 't') { cls1(); }
		else { settextcolor(d_red); puts("That command does not exist."); settextcolor(white); }
		putch('\n');
	}
	//reset command and shell commands and re-state prompt
	for (i = 0; i < 100; i++) { command_buffer[i] = NULL; }
	for (i = 0; i < 100; i++) { shell_command[i] = NULL; }
	command_buffer_count = 0;
	prompt_line(0);
}
void get_arg(unsigned char get_command_buffer) {
	
}

