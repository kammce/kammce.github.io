No restrictions are placed on the use of these files. (current source)

NOTICE: you agree (whether you have read this or not) to not hold anyone responsible for anything that might happen due to the use of these files.

The compiled version is already compiled. Making edits to the code and running the 'compile.sh' file will overwrite the old KinX.img file with the new one.

You need 'nasm' 'gcc' and 'ld' (basically, you need linux) to build this OS.

Use Qemu or Boches to Run the KinX.img file.
When it boots up, enter in this command into grub:

grub> kernel 200+43

Once the OS shows up, type help, and view the possible commands.
