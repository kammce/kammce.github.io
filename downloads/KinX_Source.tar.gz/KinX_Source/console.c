/*  Desc: I/O Console */

#include <core.h>
#include <cpu.h>
#include <shell.h>
#include <define.h>

void *memcpy(void *dest, const void *src, size_t count)
{
    const char *sp = (const char *)src;
    char *dp = (char *)dest;
    for(; count != 0; count--) *dp++ = *sp++;
    return dest;
}

void *memset(void *dest, char val, size_t count)
{
    char *temp = (char *)dest;
    for( ; count != 0; count--) *temp++ = val;
    return dest;
}

unsigned short *memsetw(unsigned short *dest, unsigned short val, size_t count)
{
    unsigned short *temp = (unsigned short *)dest;
    for( ; count != 0; count--) *temp++ = val;
    return dest;
}

size_t strlen(const char *str)
{
    size_t retval;
    for(retval = 0; *str != '\0'; str++) retval++;
    return retval;
}
size_t strlen2(const char * str)
{
    int retval;
    for(retval = 0; str[retval] != '\0'; retval++) { }
    return retval;
}
char *clear_char(char * c1, int sum) {
	int i;
	for (i = 0; i < sum; i++) { c1[i] = NULL; }
	return c1;
}
unsigned char char_compare (unsigned char * c1, unsigned char * c2) {
	int i;
	if (strlen(c1) != strlen(c2)) {
		return 'f';
	}
	for (i = '\0'; i < strlen(c1); i++)
    {
		if(c1[i] != '\0' && c2[i] != '\0') {
        	if (c1[i] != c2[i]) { return 'f'; }
		} else if(c1[i] == '\0' && c2[i] == '\0') {
        	return 'f';
		} else {
			return 'f';
		}
    }
	return 't';
}
unsigned char command_compare (unsigned char * c1, unsigned char * c2) {
	int i;
	for (i = '\0'; i < strlen(c1); i++)
    {
		if(c1[i] != '\0' && c2[i] != '\0') {
        	if (c1[i] != c2[i]) { return 'f'; }
		} else if(c1[i] == ' ' && c2[i] == '\0') {
        	return 't';
		} else {
			return 'f';
		}
    }
	return 't';
}

char * itoa( int num ) {
	int bNegative = 0;
	if( num < 0) { bNegative = 1; }
	char str[11];
	int i = 0;
	while( num != 0) {
		str[i++] = num % 10 + '0';
		num /= 10;
	}
	str[i++] = '\0';
	int j = 0;
	char f_str[11];
	i = i-2;
	while( i != -1 ) {
		f_str[j] = str[i];
		j++; i--;
	}
	return f_str;
}
void puti( int num ) {
	int bNegative = 0;
	if( num < 0) { bNegative = 1; }
	char str[11];
	int i = 0;
	while( num != 0) {
		str[i++] = num % 10 + '0';
		num /= 10;
	}
	str[i++] = '\0';
	int j = 0;
	char f_str[11];
	i = i-2;
	while( i != -1 ) {
		f_str[j] = str[i];
		j++; i--;
	}
	puts(f_str);
}
int pow(int num, short int power) {
	int fin_num = num;
	int org_num = num;
	int i;
	if(power == 0) { return 1; }
	if(power == 1) { return org_num; }
	for(i = 2; i <= power; i++) {
		fin_num *= org_num;
	}
	return fin_num;
}
int ascii_to_number(char convert_num) {
	int converted = (int) convert_num;
	converted -= 48;
	if(converted > 9) { return 11; }
	return converted;
}
int atoi( char * c ) {
	int num_place = 0;
	int ru = 0;
	int rd = 0;
	int num = 0;
	int negative = 0;
	if(c[0] == '-') { negative = -1; }
	for (ru = strlen2(c); ru > -1; ru--) {
		if(ascii_to_number(c[ru]) == 11) { break; }
		num += (ascii_to_number(c[ru]) * pow(10,rd));
		rd++;
	}
	if(negative == -1) { num *= -1; }
	return num;
}
/*unsigned char clear_char(unsigned char *clear_var) {
	int i;
	for (i = 0; i < strlen(clear_var); i++)
    { clear_var[i] = '\0'; }
	return clear_var;
} */

//=======================================================

/* These define our textpointer, our background and foreground
*  colors (attributes), and x and y cursor coordinates */
unsigned short *textmemptr;
int attrib = 0x0F;
int csr_x = 0, csr_y = 0;
int prompt_limit = 0;

void alter_pl(unsigned int pl) {
	prompt_limit = pl;
}

void alter_x(unsigned int new_x) {
	csr_x = new_x;
}
void alter_y(unsigned int new_y) {
	csr_y = new_y;
}

/* Scrolls the screen */
void scroll(void)
{
    unsigned blank, temp;

    /* A blank is defined as a space... we need to give it
    *  backcolor too */
    blank = 0x20 | (attrib << 8);

    /* Row 25 is the end, this means we need to scroll up */
    if(csr_y >= 24)
    {
        /* Move the current text chunk that makes up the screen
        *  back in the buffer by a line */
        temp = csr_y - 24 + 1;
        memcpy (textmemptr, textmemptr + temp * 80, (24 - temp) * 80 * 2);

        /* Finally, we set the chunk of memory that occupies
        *  the last line of text to our 'blank' character */
        memsetw (textmemptr + (24 - temp) * 80, blank, 80);
        csr_y = 24 - 1;
    }
}
void taskbar(unsigned char c, unsigned char colour, int x, int y)
{
	attrib = colour;
    unsigned short *where;
	int i;
	for(i=0;i<80;i++) {
		where = textmemptr + (y * 80 + (x+i));
		*where = c | (attrib << 8);
	}
	attrib = 0x0F;
}
void display_cursor_loc()
{
	puts("cursor-y: "); puti(csr_y); putch('\n');
	puts("cursor-x: "); puti(csr_x); putch('\n');
}
/* Updates the hardware cursor: the little blinking line
*  on the screen under the last character pressed! */
void move_csr(void)
{
    unsigned temp;

    /* The equation for finding the index in a linear
    *  chunk of memory can be represented by:
    *  Index = [(y * width) + x] */
    temp = csr_y * 80 + csr_x;

    /* This sends a command to indicies 14 and 15 in the
    *  CRT Control Register of the VGA controller. These
    *  are the high and low bytes of the index that show
    *  where the hardware cursor is to be 'blinking'. To
    *  learn more, you should look up some VGA specific
    *  programming documents. A great start to graphics:
    *  http://www.brackeen.com/home/vga */
    outportb(0x3D4, 14);
    outportb(0x3D5, temp >> 8);
    outportb(0x3D4, 15);
    outportb(0x3D5, temp);
}

/* Clears the screen */
void cls()
{
    unsigned blank;
    int i;

    /* Again, we need the 'short' that will be used to
    *  represent a space with color */
    blank = 0x20 | (attrib << 8);

    /* Sets the entire screen to spaces in our current
    *  color */
    for(i = 0; i < 25; i++) {
        memsetw (textmemptr + i * 80, blank, 80);
	}

    /* Update out virtual cursor, and then move the
    *  hardware cursor */
    csr_x = 0;
    csr_y = 0;
    move_csr();
}
void cls1()
{
    unsigned blank;
    int i;

    /* Again, we need the 'short' that will be used to
    *  represent a space with color */
    blank = 0x20 | (attrib << 8);

    /* Sets the entire screen to spaces in our current
    *  color */
    for(i = 0; i < 25; i++) {
        memsetw (textmemptr + i * 80, blank, 80);
	}

    /* Update out virtual cursor, and then move the
    *  hardware cursor */
    csr_x = 0;
    csr_y = 0;
    move_csr();
}

/* Puts a single character on the screen */
void putch(unsigned char c)
{
    unsigned short *where;
    unsigned att = attrib << 8;
    /* Handle a backspace, by moving the cursor back one space */
    if(c == 0x08)
    {
        if(csr_x < prompt_limit) { csr_x++; }
        if(csr_x != prompt_limit) { csr_x--; 
		where = textmemptr + (csr_y * 80 + csr_x);
        *where = '\0' | att;
        }
        if(csr_x == 0) { csr_x = 0; }
    }
    /* Handles a tab by incrementing the cursor's x, but only
    *  to a point that will make it divisible by 8 */
    else if(c == 0x09)
    {
        csr_x = (csr_x + 8) & ~(8 - 1);
    }
    /* Handles a 'Carriage Return', which simply brings the
    *  cursor back to the margin */
    else if(c == '\r')
    {
        csr_x = 0;
    }
    /* We handle our newlines the way DOS and the BIOS do: we
    *  treat it as if a 'CR' was also there, so we bring the
    *  cursor to the margin and we increment the 'y' value */
    else if(c == '\n')
    {
        csr_x = 0;
        csr_y++;
    }
    /* Any character greater than and including a space, is a
    *  printable character. The equation for finding the index
    *  in a linear chunk of memory can be represented by:
    *  Index = [(y * width) + x] */
    else if(c >= ' ')
    {
        where = textmemptr + (csr_y * 80 + csr_x);
        *where = c | att;	/* Character AND attributes: color */
        csr_x++;
    }

    /* If the cursor has reached the edge of the screen's width, we
    *  insert a new line in there */
    if(csr_x >= 80)
    {
        csr_x = 0;
        csr_y++;
    }

    /* Scroll the screen if needed, and finally move the cursor */
    scroll();
    move_csr();
}

/* Uses the above routine to output a string... */
void puts(unsigned char *text)
{
    int i;

    for (i = 0; i < strlen(text); i++)
    {
		if(text[i] == '\0') { break; } else { putch(text[i]); }
    }
}

void settextcolor(unsigned char color)
{
    attrib = color;
}
/*
void mem_str_cpy(char *dest[], unsigned char mov, int start, int end) {
	int i_s;
	int i_0 = 0;
	for (i_s = start; i_s < end; i_s++) {
        dest[i_s] = mov[i_0];
		i_0++;
		if(mov[i_0] == '\0') { break; }
    }
}
*/

/* Sets our text-mode VGA pointer, then clears the screen for us */
void init_video(void)
{
    textmemptr = (unsigned short *)0xB8000;
	//textmemptr = (unsigned short *)0x1112;
    cls();
	taskbar(' ', 0x20, 0, 0);
}
