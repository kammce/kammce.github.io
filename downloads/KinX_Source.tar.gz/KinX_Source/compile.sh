#! /bin/sh

echo "Assembling kernel:"
nasm -f elf -o loader.o loader.asm
#nasm -f elf -o 90x60.o 90x60.asm

echo "\nCompiling kernel:"
gcc -o console.o -c console.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

gcc -o gdt.o -c gdt.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

gcc -o idt.o -c idt.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

gcc -o isrs.o -c isrs.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

gcc -o irq.o -c irq.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

gcc -o timer.o -c timer.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

gcc -o keyboard_driver.o -c keyboard_driver.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

gcc -o KinDOS.o -c KinDOS.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

gcc -o echo.o -c echo.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

gcc -o math.o -c math.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

#gcc -o KinX-Logo.o -c KinX-Logo.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

gcc -o cpu.o -c cpu.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

gcc -o kernel.o -c kernel.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

gcc -o date.o -c date.c -O -fstrength-reduce -fomit-frame-pointer -nostartfiles -nodefaultlibs -nostdlib -finline-functions -nostdinc -fno-builtin -I./include -m32

echo "\nLinking your kernel:"

ld -T linker.ld -o kernel.elf loader.o kernel.o cpu.o console.o  gdt.o idt.o isrs.o irq.o timer.o keyboard_driver.o KinDOS.o echo.o math.o date.o -melf_i386

#echo "\nApending bootloader (grub):"
#cat boot/grub/stage1 boot/grub/stage2 boot/grub/pad > grub_boot_loader
#cat grub_boot_loader kernel.elf > KinX.img

echo "\nCleaning up (removing *.o files):"
rm *.o

echo "\ndone"
