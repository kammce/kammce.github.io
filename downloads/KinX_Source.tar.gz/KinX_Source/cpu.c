#include <cpu.h>
#include <core.h>

unsigned char inportb (unsigned short _port)
{
    unsigned char rv;
    __asm__ __volatile__ ("inb %1, %0" : "=a" (rv) : "dN" (_port));
    return rv;
}
void outportb (unsigned short _port, unsigned char _data)
{
    __asm__ __volatile__ ("outb %1, %0" : : "dN" (_port), "a" (_data));
}
void hlt(void)
{
	__asm__ __volatile__("hlt" : : : "memory");
}
/*void invlpg(_dword_union address)
{
	__asm__ __volatile__("invlpg (%0)" : : "r"(address.u));
}*/
void disableInts(void)
{
	__asm__ __volatile__("cli");
}
void enableInts(void)
{
	__asm__ __volatile__("sti");
}
void getdate(void)
{
	//__asm__ __volatile__("sti");
}
