No restrictions are placed on the use of these files. (current build)

NOTICE: you agree (whether you have read this or not) to not hold anyone responsible for anything that might happen due to the use of these files.

Use Qemu or Boches to Run the KinX.img file.
When it boots up, enter in this command into grub:

grub> kernel 200+43

Once the OS shows up, type help, and view the possible commands.
